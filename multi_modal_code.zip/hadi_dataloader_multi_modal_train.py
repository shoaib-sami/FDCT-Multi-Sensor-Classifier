import torch, torchvision

from torchvision.transforms import ToTensor, ToPILImage
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
from PIL import Image
import PIL
from torchvision import transforms
from torchvision.transforms import ToTensor, ToPILImage
import numpy as np
import random
import torch.nn.functional as F
import tarfile
import io
import os
import pandas as pd
import cv2
import config
from torch.utils.data import Dataset
import torch
import re

class YourDataset(Dataset):
    def __init__(self, img_dir, transform=None):
        self.img_dir = '/home/shoaibmerajsami/Desktop/atr hadi final/Multi_domain_fusion_dr_asif/dataset/train_llm/'

        #self.img_dir2 = img_dir
        
        #self.transform = transform
        self.labels = sorted(os.listdir(self.img_dir), key=lambda x: int(x))

        lb = [int(l) - 1 for l in self.labels]
        self.labels_ohe = lb
        # self.labels_ohe = F.one_hot(torch.as_tensor(lb), num_classes=11) # I have changed from 11 to 5 sami

        self.img_lists = []
        self.all_class_dirs = [os.path.join(self.img_dir, label) for label in self.labels]

        for class_dir in self.all_class_dirs[:7]:  # For 5 classes
            self.img_lists += os.listdir(class_dir)

        """

        self.labels2 = sorted(os.listdir(self.img_dir2), key=lambda x: int(x))

        lb2 = [int(l) - 1 for l in self.labels2]
        self.labels_ohe2 = lb2
        # self.labels_ohe = F.one_hot(torch.as_tensor(lb), num_classes=11) # I have changed from 11 to 5 sami

        self.img_lists2 = []
        self.all_class_dirs2 = [os.path.join(self.img_dir2, label2) for label in self.labels2]

        for class_dir2 in self.all_class_dirs2[:10]:  # For 5 classes
            self.img_lists2 += os.listdir(class_dir2)
        """
        
        self.i = 0
        self.transform = transforms.Compose([
            transforms.Resize((224, 224)),
            #transforms.CenterCrop(64),
            transforms.ToTensor(),
            #transforms.Lambda(lambda x: x.repeat(3,1,1)),
            # transforms.Normalize(mean=[0.485, 0.456, 0.406],
            #                     std=[0.229, 0.224, 0.225] )
        ])

    def __len__(self):
        return len(self.img_lists)

    def __getitem__(self, index):
        all_img_abs_dir = []
        for class_dir in self.all_class_dirs[:7]:  # for 5 classes
            all_img_abs_dir += [os.path.join(class_dir, img_name) for img_name in os.listdir(class_dir)]

        image_abs_dir = all_img_abs_dir[index]
        #img_train_mwir ='/home/shoaibmerajsami/Desktop/atr hadi final/MW_NVESD/train/'
        image_abs_dir_mwir = image_abs_dir.replace('train_llm','train_mlm')
        label = int(image_abs_dir.split("/")[-2])
        image_name_mwir = image_abs_dir.split("/")[-1]
        image_number = (image_name_mwir.split(".")[0]).split(" ")[-1][3:]
        image_class = ((image_name_mwir.split(".")[0]).split(" ")[-2]).split(" ")[-1]
        #print(image_class)
        image_new_name = image_class+' MLM'+image_number+'.png'
        image_dir_mlm = image_abs_dir_mwir.replace(image_name_mwir,image_new_name)#image_abs_dir.split("/")[-2]#+image_new_name
        #print(image_dir_mlm)
        if os.path.exists(image_dir_mlm):
            pass
        else:
            image_number = str(int(image_number)+1)
            image_new_name = image_class+' MLM'+image_number+'.png'
            image_dir_mlm = image_abs_dir_mwir.replace(image_name_mwir,image_new_name)#image_abs_dir.split("/")[-2]#+image_new_name
            #print(image_dir_mlm)            
            if os.path.exists(image_abs_dir_mwir):
                pass
            else:
                image_number = str(int(image_number)+1)
                image_new_name = image_class+' MLM'+image_number+'.png'
                image_dir_mlm = image_abs_dir_mwir.replace(image_name_mwir,image_new_name)#image_abs_dir.split("/")[-2]#+image_new_name
                #print(image_dir_mlm)  
                
                #print("Hello I have converted String 2nd time``````````````````````'''''''")            
                if os.path.exists(image_abs_dir_mwir):
                    pass
                else:
                    image_number = str(int(image_number)+1)
                    image_new_name = image_class+' MLM'+image_number+'.png'
                    image_dir_mlm = image_abs_dir_mwir.replace(image_name_mwir,image_new_name)#image_abs_dir.split("/")[-2]#+image_new_name
                    #print(image_dir_mlm)
                if os.path.exists(image_dir_mlm):
                    pass
                else:
                    image_number = str(int(image_number)+1)
                    image_new_name = image_class+' MLM'+image_number+'.png'
                    image_dir_mlm = image_abs_dir_mwir.replace(image_name_mwir,image_new_name)#image_abs_dir.split("/")[-2]#+image_new_name
                    #print(image_dir_mlm)            
                    if os.path.exists(image_abs_dir_mwir):
                        pass
                    else:
                        image_number = str(int(image_number)+1)
                        image_new_name = image_class+' MLM'+image_number+'.png'
                        image_dir_mlm = image_abs_dir_mwir.replace(image_name_mwir,image_new_name)#image_abs_dir.split("/")[-2]#+image_new_name
                        #print(image_dir_mlm)  
                        
                        #print("Hello I have converted String 2nd time``````````````````````'''''''")            
                        if os.path.exists(image_abs_dir_mwir):
                            pass
                        else:
                            image_number = str(int(image_number)+1)
                            image_new_name = image_class+' MLM'+image_number+'.png'
                            image_dir_mlm = image_abs_dir_mwir.replace(image_name_mwir,image_new_name)#image_abs_dir.split("/")[-2]#+image_new_name
                            #print(image_dir_mlm)  
                      
                    
                    
                                                                                   

        try:
            img = Image.open(image_abs_dir) #.convert("L")
            #img = img
            img1 = self.transform(img)
            if os.path.exists(image_dir_mlm):
                pair_unpair = 'pair'
            else:
                image_dir_mlm = image_abs_dir
                pair_unpair = 'unpair'
                self.i+=1
                if self.i % 5 ==1:
                    print(" What happen")
                    print(self.i)

            img_mwir = Image.open(image_dir_mlm)
            img_mwir2 =self.transform(img_mwir)
           
            #x.unsqueeze_(0) # done august 16 2022 by Shoaib
            #img = img.repeat(1, 3, 1, 1)   # done august 16 2022
            #x = x.view(-1, 72, 72)
            # vis = np.concatenate((img, img, img), axis=1)
            
            return img1,img_mwir2,pair_unpair, self.labels_ohe[label - 1]

        except PIL.UnidentifiedImageError as ui:
            #print(image_abs_dir)
            return None, None