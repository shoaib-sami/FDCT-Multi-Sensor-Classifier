- base_solver.py
> The basic class of solver.

- clip_solver.py
> CLIP: Learning Transferable Visual Models From Natural Language Supervision

- declip_solver.py
> DeCLIP: Supervision Exists Everywhere: A Data Efficient Contrastive Language-Image Pre-training Paradigm.

- filip_solver.py
> FILIP:  FINE-GRAINED INTERACTIVE LANGUAGE- IMAGE PRE-TRAINING

- slip_solver.py
> SLIP: Self-supervision meets Language-Image Pre-training
